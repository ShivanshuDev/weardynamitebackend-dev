"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const url_1 = require("url");
const __filename = (0, url_1.fileURLToPath)(import.meta.url);
const __dirname = path_1.default.dirname(__filename);
const CATEGORIES = ['Apparel', 'Accessories', 'Footwear'];
const SUB_CATEGORIES = {
    Apparel: ['T-Shirts', 'Hoodies', 'Jackets', 'Bottoms', 'Sweaters', 'Shirts', 'Outerwear'],
    Accessories: ['Hats', 'Bags', 'Belts', 'Wallets'],
    Footwear: ['Sneakers', 'Boots', 'Formals'],
};
const COLORS = ['Pitch Black', 'Ghost White', 'Crimson Red', 'Navy Blue', 'Olive Green', 'Classic Grey', 'Mustard Yellow', 'Sand Beige', 'Deep Purple', 'Charcoal'];
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const FITS = ['Oversized', 'Regular Fit', 'Slim Fit', 'Boxy Fit', 'Relaxed Fit'];
const NECK_TYPES = ['Crew Neck', 'V-Neck', 'Polo Collar', 'High Neck', 'Hooded', 'Round Neck'];
const OCCASIONS = ['Casual Wear', 'Partywear', 'Streetwear', 'Gym & Sports', 'Semi-Formal', 'Office Wear', 'Regular Use'];
const PHOTO_IDS = [
    '1521572163474-6864f9cf17ab', '1556821840-3a63f95609a7', '1594633312681-425c7b97ccd1', '1588850567045-1612b804af4b',
    '1591047139829-d91aecb6caea', '1576871337622-98d48d38537c', '1544816155-12df9643f363', '1552346154-21d32810aba3',
    '1576871337632-b9aef4c17ab9', '1541099649105-f69ad21f3246', '1576566588028-4147f3842f27', '1552902865-b72c031ac5ea',
    '1586363104864-50e2246b7211', '1551028719-00167b16eac5', '1635397174557-3588fef6b1fc', '1596755094514-f87e34085b2c',
    '1553062407-98eeb94c6a62', '1614613535308-eb5fbd3d2c17', '1503342217505-b0a15ec3261c', '1491553895911-0055eca6402d',
    '1542291026-7eec264c27ff', '1523275335684-37898b6baf30', '1485968579580-b6d095142e6e', '1505740420928-5e560c06d30e',
    '1503341455253-b2e72fbb0dbb', '1441984904996-e0b6ba687e07', '1483985988355-763728e1935b', '1523381210434-271e8be1f52b',
    '1576566588028-4147f3842f27', '1556196148-de530cba9974', '1571513722275-4b41940f54b8', '1581375074612-d7af0f67ca8f',
    '1590117560339-01742a2618ef', '1511707171634-5f897ff02aa9', '1526170315830-14dd51013c41', '1553531384-397cf00b20be',
    '1560243563-0c40b3ef527c', '1562157876-21f44c8ed23a', '1598033129183-c405072da647', '1603541454133-569b91316f73',
    '1605333556536-eebdb8aecebf', '1612423284922-2970a29bd481', '1617137968427-85924c800a22', '1618354691792-d1d429fa2797',
    '1620799140408-edc6dcb6d633', '1622470953794-aa01db4b2568', '1631542470650-62e92c24e6a0',
];
const generateProducts = () => {
    const products = [];
    const statusCycle = ['Active', 'In Stock', 'Under Review', 'Out of Stock'];
    for (let i = 1; i <= 200; i++) {
        const category = CATEGORIES[i % CATEGORIES.length];
        const subCategories = SUB_CATEGORIES[category];
        const subCategory = subCategories[i % subCategories.length];
        const color = COLORS[i % COLORS.length];
        const fit = FITS[i % FITS.length];
        const neckType = NECK_TYPES[i % NECK_TYPES.length];
        const occasion = OCCASIONS[i % OCCASIONS.length];
        const status = statusCycle[i % statusCycle.length];
        const price = Math.floor(Math.random() * 2000) + 499; // 499 to 2499 INR
        const salePrice = Math.random() > 0.6 ? price - 200 : null;
        const name = `Premium ${color} ${subCategory}`;
        const urlHandle = `${color.toLowerCase().replace(' ', '-')}-${subCategory.toLowerCase()}-${i}`;
        products.push({
            PK: `PRODUCT#${i}`,
            SK: 'PRODUCT',
            productId: String(i),
            name,
            subtitle: `The Ultimate ${occasion} Essential`,
            brand: 'Wear Dynamite',
            category,
            subCategory,
            description: `Elevate your ${occasion.toLowerCase()} with our Premium ${name}. Crafted from high-density 240+ GSM organic cotton, this ${subCategory.toLowerCase()} features a ${fit.toLowerCase()} and a classic ${neckType.toLowerCase()}. Perfect for ${occasion.toLowerCase()} and multiple styling options.`,
            mrp: price,
            salePrice: salePrice,
            currency: 'INR',
            taxPercent: 12,
            sku: `WD-${category.substring(0, 1)}${subCategory.substring(0, 1)}-${i.toString().padStart(3, '0')}`,
            barcode: `890${Math.floor(Math.random() * 9000000000) + 1000000000}`,
            stock: status === 'Out of Stock' ? 0 : Math.floor(Math.random() * 200) + 10,
            lowStockAlert: 20,
            primaryColor: color,
            primarySize: 'M',
            fit,
            neckType,
            occasion,
            variants: [
                {
                    color: color,
                    sizes: SIZES.map(s => ({ size: s, stock: status === 'Out of Stock' ? 0 : Math.floor(Math.random() * 50) + 5 }))
                },
                {
                    color: COLORS[(i + 1) % COLORS.length],
                    sizes: SIZES.map(s => ({ size: s, stock: status === 'Out of Stock' ? 0 : Math.floor(Math.random() * 20) }))
                }
            ],
            images: [
                `https://images.unsplash.com/photo-${PHOTO_IDS[i % PHOTO_IDS.length]}?q=80&w=800&auto=format&fit=crop`,
                `https://images.unsplash.com/photo-${PHOTO_IDS[(i + 1) % PHOTO_IDS.length]}?q=80&w=800&auto=format&fit=crop`
            ],
            specs: [
                { key: 'Material', value: '100% Organic Super-Combed Cotton' },
                { key: 'GSM', value: '240 GSM Heavyweight' },
                { key: 'Fit', value: fit },
                { key: 'Neck', value: neckType },
                { key: 'Occasion', value: occasion }
            ],
            keywords: [color.toLowerCase(), subCategory.toLowerCase(), fit.toLowerCase(), neckType.toLowerCase(), occasion.toLowerCase(), 'regular use', 'streetwear', 'premium'],
            seoTitle: `Shop ${name} - ${fit} ${neckType} | Wear Dynamite`,
            seoDescription: `Buy ${name} at ₹${salePrice || price}. Featuring a ${fit} and ${neckType}. Ideal for ${occasion}. High-quality sustainable fashion.`,
            urlHandle,
            codAvailable: true,
            status,
            salesCount: Math.floor(Math.random() * 500),
            isNewArrival: i <= 30,
            isBestSeller: i % 15 === 0,
            createdAt: new Date(Date.now() - Math.random() * 60 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date().toISOString()
        });
    }
    return products;
};
const seed = () => {
    console.log('🌱 Starting database expansion seed (200 products)...');
    const products = generateProducts();
    const dbContent = { items: products }; // Note: Overwriting previous test employees for now to focus on products, or merge if needed
    const DB_PATH = path_1.default.join(__dirname, '../../db.json');
    fs_1.default.writeFileSync(DB_PATH, JSON.stringify(dbContent, null, 2));
    console.log(`✅ Seed complete! Generated ${products.length} refined products in db.json.`);
};
seed();
