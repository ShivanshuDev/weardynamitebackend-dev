"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const uuid_1 = require("uuid");
const DB_PATH = path_1.default.join(__dirname, '../../db.json');
const CATEGORIES = ['Apparel', 'Accessories', 'Footwear'];
const COLORS = ['Pitch Black', 'Ghost White', 'Crimson Red', 'Navy Blue', 'Olive Green', 'Classic Grey', 'Mustard Yellow', 'Sand Beige', 'Deep Purple', 'Charcoal'];
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const generateId = () => (0, uuid_1.v4)();
const seed = () => {
    console.log('🌱 Starting Master Institutional Seed...');
    const items = [];
    const now = new Date();
    // 1. PRODUCTS (200)
    for (let i = 1; i <= 200; i++) {
        const id = String(i);
        items.push({
            PK: `PRODUCT#${id}`,
            SK: 'PRODUCT',
            productId: id,
            name: `Premium ${COLORS[i % COLORS.length]} ${CATEGORIES[i % CATEGORIES.length]} Item`,
            category: CATEGORIES[i % CATEGORIES.length],
            status: i % 10 === 0 ? 'Out of Stock' : 'Active',
            mrp: 999 + (i * 10),
            salePrice: 799 + (i * 10),
            stock: 50 + i,
            salesCount: i * 2,
            isNewArrival: i < 20,
            createdAt: new Date(now.getTime() - i * 3600000).toISOString(),
            updatedAt: now.toISOString()
        });
    }
    // 2. EMPLOYEES (15)
    const roles = ['Manager', 'Senior Tailor', 'Sales Executive', 'Inventory Lead', 'Designer'];
    for (let i = 1; i <= 15; i++) {
        const id = `EMP${i.toString().padStart(3, '0')}`;
        items.push({
            PK: `EMPLOYEE#${id}`,
            SK: 'EMPLOYEE',
            employeeId: id,
            name: `Staff Member ${i}`,
            role: roles[i % roles.length],
            status: 'Active',
            email: `staff${i}@weardynamite.com`,
            phone: `+91 98765 000${i.toString().padStart(2, '0')}`,
            baseSalary: 15000 + (i * 1000),
            joiningDate: '2025-01-01',
            createdAt: now.toISOString(),
            updatedAt: now.toISOString()
        });
    }
    // 3. ATTENDANCE (Past 30 Days for all employees)
    for (let d = 0; d < 30; d++) {
        const date = new Date(now.getTime() - d * 24 * 3600000).toISOString().split('T')[0];
        const dayName = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
        for (let i = 1; i <= 15; i++) {
            const empId = `EMP${i.toString().padStart(3, '0')}`;
            const isWeekend = dayName === 'Sunday';
            const status = isWeekend ? 'Off' : (Math.random() > 0.9 ? 'Absent' : 'Present');
            items.push({
                PK: `ATTENDANCE#${empId}#${date}`,
                SK: 'ATTENDANCE',
                employeeId: empId,
                date,
                status,
                checkIn: status === 'Present' ? '09:00 AM' : null,
                checkOut: status === 'Present' ? '06:30 PM' : null,
                shift: 'Morning',
                createdAt: now.toISOString()
            });
        }
    }
    // 4. CMS (Site Content)
    items.push({
        PK: 'CMS#SITE',
        SK: 'CMS',
        home: {
            carousel: [
                { image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e07?q=80&w=2070', title: 'DYNAMITE 2026', subtitle: 'REDEFINING LUXURY STREETWEAR' },
                { image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=2070', title: 'SPRING DROP', subtitle: 'LIMITED EDITION ARRIVALS' }
            ],
            megaPromos: [
                { title: 'FLASH SALE', subtitle: 'UP TO 50% OFF', image: 'https://images.unsplash.com/photo-1523381210434-271e8be1F52b?q=80&w=2000' }
            ],
            videoBlock: { title: 'ENGINEERED FOR MOTION', perks: ['Breathable', 'Sustainable', 'Heavyweight'] },
            vipBanner: { title: 'JOIN THE INNER CIRCLE', subtitle: 'GET EXCLUSIVE EARLY ACCESS' },
            whatWeDo: { title: 'CRAFTING EXCELLENCE', subtitle: 'FROM RAW THREAD TO FINISHED ART' },
            productSections: { newArrivals: { title: 'NEW RELEASES' }, mostPopular: { title: 'TRENDING NOW' } }
        },
        standard: {
            features: [
                { title: 'Ethical Sourcing', description: 'Every fiber told a story of fair wages and organic roots.', icon: 'Leaf' },
                { title: 'Besopke Craft', description: 'Hand-finished in our urban studios.', icon: 'Wind' }
            ]
        },
        process: {
            hero: { title: 'OUR CRAFT', subtitle: 'MINIMALISM MEETS MASTERY' },
            steps: [
                { title: 'Conceptualization', content: 'Where raw ideas meet architectural patterns.' },
                { title: 'Execution', content: 'Precision tailoring with premium textiles.' }
            ],
            cta: { title: 'EXPERIENCE THE FIT' }
        },
        policies: {
            shippingAndReturns: {
                pageTitle: 'LOGISTICS & CIRCULATION',
                shippingProcess: { title: 'EXPRESS DISPATCH', content: 'Orders processed within 24 hours of confirmation.' },
                refundPolicy: { title: 'FLAWLESS RETURNS', content: '30-day no-questions-asked return policy for unworn items.' }
            },
            faq: {
                pageTitle: 'FREQUENTLY ASKED',
                items: [
                    { question: 'When is the next drop?', answer: 'Follow our official Instagram for countdowns.' },
                    { question: 'Do you ship internationally?', answer: 'Yes, we ship to over 50 countries worldwide.' }
                ]
            },
            privacy: {
                pageTitle: 'DATA SOVEREIGNTY',
                content: 'Your privacy is our priority. We nunca share your data with third parties.'
            }
        },
        contact: { direct: { phone: ['+91 1111111111'], email: 'support@weardynamite.com' } }
    });
    // 5. INQUIRIES & SUBSCRIBERS
    for (let i = 1; i <= 50; i++) {
        items.push({
            PK: `INQUIRY#${i}`,
            SK: 'INQUIRY',
            inquiryId: String(i),
            name: `Customer ${i}`,
            email: `customer${i}@gmail.com`,
            subject: 'Product Inquiry',
            message: 'Can you tell me more about the sizing?',
            status: i % 3 === 0 ? 'Resolved' : 'Pending',
            createdAt: now.toISOString()
        });
        items.push({
            PK: `SUBSCRIBER#customer${i}@gmail.com`,
            SK: 'SUBSCRIBER',
            email: `customer${i}@gmail.com`,
            status: 'Subscribed',
            createdAt: now.toISOString()
        });
    }
    // 6. LEDGER (Initial Activity)
    items.push({
        PK: 'LEDGER#SUMMARY',
        SK: 'SUMMARY',
        openingBalance: 500000,
        currentBalance: 650000,
        updatedAt: now.toISOString()
    });
    const dbContent = { items };
    fs_1.default.writeFileSync(DB_PATH, JSON.stringify(dbContent, null, 2));
    console.log(`✅ Master Seed Complete! ${items.length} records generated.`);
};
seed();
