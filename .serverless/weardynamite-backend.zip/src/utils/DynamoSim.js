"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateId = exports.transactWrite = exports.conditionalUpdate = exports.updateItem = exports.scan = exports.queryGSI = exports.query = exports.deleteItem = exports.getItem = exports.put = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const uuid_1 = require("uuid");
const DB_PATH = path_1.default.join(__dirname, '../../db.json');
// ────────────────────────────────────────────────────────────────────────────
//  Low-level helpers
// ────────────────────────────────────────────────────────────────────────────
const readDb = () => {
    if (!fs_1.default.existsSync(DB_PATH)) {
        fs_1.default.writeFileSync(DB_PATH, JSON.stringify({ items: [] }, null, 2));
    }
    return JSON.parse(fs_1.default.readFileSync(DB_PATH, 'utf-8'));
};
const writeDb = (db) => {
    fs_1.default.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
};
// ────────────────────────────────────────────────────────────────────────────
//  Core Operations  (mirrors DynamoDB API shape)
// ────────────────────────────────────────────────────────────────────────────
/** Put (upsert) an item. Adds createdAt / updatedAt automatically. */
const put = (item) => {
    const db = readDb();
    const now = new Date().toISOString();
    const existing = db.items.findIndex(i => i.PK === item.PK && i.SK === item.SK);
    const record = { ...item, updatedAt: now };
    if (existing === -1) {
        record.id = (0, uuid_1.v4)();
        record.createdAt = now;
        db.items.push(record);
    }
    else {
        record.id = db.items[existing].id;
        record.createdAt = db.items[existing].createdAt;
        db.items[existing] = record;
    }
    writeDb(db);
    return record;
};
exports.put = put;
/** Get a single item by PK + SK. */
const getItem = (PK, SK) => {
    const db = readDb();
    return db.items.find(i => i.PK === PK && i.SK === SK);
};
exports.getItem = getItem;
/** Delete an item by PK + SK. */
const deleteItem = (PK, SK) => {
    const db = readDb();
    const before = db.items.length;
    db.items = db.items.filter(i => !(i.PK === PK && i.SK === SK));
    writeDb(db);
    return db.items.length < before;
};
exports.deleteItem = deleteItem;
/**
 * Query items by PK prefix and optional SK prefix.
 * Simulates DynamoDB begins_with behaviour.
 */
const query = (PKprefix, SKprefix) => {
    const db = readDb();
    return db.items.filter(i => {
        const pkMatch = i.PK.startsWith(PKprefix);
        const skMatch = SKprefix ? i.SK.startsWith(SKprefix) : true;
        return pkMatch && skMatch;
    });
};
exports.query = query;
/**
 * GSI Query — filter on any attribute value.
 * Simulates a simple Global Secondary Index.
 *
 * @param indexKey   The attribute acting as GSI partition key  (e.g. 'category')
 * @param indexValue The value to match                         (e.g. 'Apparel')
 * @param sortKey    Optional: sort results by this attribute
 * @param sortDir    'asc' | 'desc'
 */
const queryGSI = (indexKey, indexValue, sortKey, sortDir = 'asc') => {
    const db = readDb();
    let results = db.items.filter(i => i[indexKey] === indexValue);
    if (sortKey) {
        results.sort((a, b) => {
            if (a[sortKey] < b[sortKey])
                return sortDir === 'asc' ? -1 : 1;
            if (a[sortKey] > b[sortKey])
                return sortDir === 'asc' ? 1 : -1;
            return 0;
        });
    }
    return results;
};
exports.queryGSI = queryGSI;
/**
 * Scan — return all items matching an optional filter function.
 * Use sparingly (full table scan); prefer query / queryGSI.
 */
const scan = (filterFn) => {
    const db = readDb();
    return filterFn ? db.items.filter(filterFn) : db.items;
};
exports.scan = scan;
/**
 * Update specific fields on an existing item without replacing the whole record.
 */
const updateItem = (PK, SK, updates) => {
    const db = readDb();
    const idx = db.items.findIndex(i => i.PK === PK && i.SK === SK);
    if (idx === -1)
        return null;
    db.items[idx] = { ...db.items[idx], ...updates, updatedAt: new Date().toISOString() };
    writeDb(db);
    return db.items[idx];
};
exports.updateItem = updateItem;
/**
 * Conditional update — update only if the condition passes.
 * Simulates DynamoDB ConditionExpression (e.g. prevent overselling).
 */
const conditionalUpdate = (PK, SK, conditionFn, updates) => {
    const db = readDb();
    const idx = db.items.findIndex(i => i.PK === PK && i.SK === SK);
    if (idx === -1)
        return { success: false, item: null };
    if (!conditionFn(db.items[idx]))
        return { success: false, item: db.items[idx] };
    db.items[idx] = { ...db.items[idx], ...updates, updatedAt: new Date().toISOString() };
    writeDb(db);
    return { success: true, item: db.items[idx] };
};
exports.conditionalUpdate = conditionalUpdate;
/**
 * Transaction Write — executes multiple put/update operations atomically.
 * If any step throws, all changes are rolled back (in-memory only).
 */
const transactWrite = (operations) => {
    // Snapshot
    const db = readDb();
    const snapshot = JSON.stringify(db);
    try {
        operations.forEach(op => op());
        return { success: true };
    }
    catch (err) {
        // Rollback
        writeDb(JSON.parse(snapshot));
        return { success: false, error: err.message };
    }
};
exports.transactWrite = transactWrite;
const generateId = () => (0, uuid_1.v4)();
exports.generateId = generateId;
