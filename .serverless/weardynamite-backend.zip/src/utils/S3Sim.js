"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFromS3 = exports.getPresignedUploadUrl = void 0;
const uuid_1 = require("uuid");
// In production this would call AWS SDK v3 `@aws-sdk/s3-request-presigner`
// For mock/dev mode it returns a fake upload URL.
const IS_MOCK = process.env.NODE_ENV !== 'production';
const BUCKET = process.env.S3_BUCKET_NAME || 'weardynamite-assets';
const REGION = process.env.AWS_REGION || 'ap-south-1';
const getPresignedUploadUrl = async (fileName, fileType, folder = 'uploads') => {
    const fileKey = `${folder}/${(0, uuid_1.v4)()}-${fileName}`;
    const fileUrl = `https://${BUCKET}.s3.${REGION}.amazonaws.com/${fileKey}`;
    if (IS_MOCK) {
        // Return a mock URL for local development
        return {
            uploadUrl: `http://localhost:3001/mock-s3-upload?key=${encodeURIComponent(fileKey)}`,
            fileUrl,
            fileKey,
        };
    }
    // Production: use real AWS SDK
    // const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
    // const { getSignedUrl } = await import('@aws-sdk/s3-request-presigner');
    // const client = new S3Client({ region: REGION });
    // const command = new PutObjectCommand({ Bucket: BUCKET, Key: fileKey, ContentType: fileType });
    // const uploadUrl = await getSignedUrl(client, command, { expiresIn: 300 });
    // return { uploadUrl, fileUrl, fileKey };
    return { uploadUrl: fileUrl, fileUrl, fileKey };
};
exports.getPresignedUploadUrl = getPresignedUploadUrl;
const deleteFromS3 = async (fileKey) => {
    if (IS_MOCK) {
        console.log(`[S3Sim] Mock delete: ${fileKey}`);
        return;
    }
    // Production: call aws sdk DeleteObjectCommand
    console.log(`[S3] Deleting ${fileKey} from ${BUCKET}`);
};
exports.deleteFromS3 = deleteFromS3;
