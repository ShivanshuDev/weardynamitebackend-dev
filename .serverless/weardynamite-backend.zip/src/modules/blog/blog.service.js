"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteBlog = exports.patchBlogStatus = exports.updateBlog = exports.createBlog = exports.getBlog = exports.listBlogs = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const listBlogs = (adminMode = false) => {
    const blogs = db.scan(i => i.SK === 'BLOG');
    const items = adminMode ? blogs : blogs.filter(b => b.status === 'Published');
    return items.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};
exports.listBlogs = listBlogs;
const getBlog = (id) => {
    const item = db.getItem(`BLOG#${id}`, 'BLOG');
    if (!item)
        throw new Error('Blog not found');
    return item;
};
exports.getBlog = getBlog;
const createBlog = (data) => {
    const id = db.generateId();
    return db.put({ PK: `BLOG#${id}`, SK: 'BLOG', blogId: id, status: 'Draft', ...data });
};
exports.createBlog = createBlog;
const updateBlog = (id, updates) => {
    const item = db.getItem(`BLOG#${id}`, 'BLOG');
    if (!item)
        throw new Error('Blog not found');
    return db.put({ ...item, ...updates, PK: `BLOG#${id}`, SK: 'BLOG' });
};
exports.updateBlog = updateBlog;
const patchBlogStatus = (id, status) => {
    const updated = db.updateItem(`BLOG#${id}`, 'BLOG', { status });
    if (!updated)
        throw new Error('Blog not found');
    return updated;
};
exports.patchBlogStatus = patchBlogStatus;
const deleteBlog = (id) => {
    const ok = db.deleteItem(`BLOG#${id}`, 'BLOG');
    if (!ok)
        throw new Error('Blog not found');
    return { message: 'Blog deleted' };
};
exports.deleteBlog = deleteBlog;
