"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminListUsers = exports.updatePreferences = exports.setDefaultAddress = exports.deleteAddress = exports.updateAddress = exports.addAddress = exports.getAddresses = exports.updateProfile = exports.getProfile = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const getProfile = (userId) => {
    const record = db.scan(i => i.SK === 'PROFILE' && i.id === userId && i.role === 'customer')[0];
    if (!record)
        throw new Error('User not found');
    const { password, ...safe } = record;
    return safe;
};
exports.getProfile = getProfile;
const updateProfile = (userId, updates) => {
    const record = db.scan(i => i.SK === 'PROFILE' && i.id === userId && i.role === 'customer')[0];
    if (!record)
        throw new Error('User not found');
    const updated = db.updateItem(record.PK, 'PROFILE', updates);
    if (!updated)
        throw new Error('Update failed');
    const { password, ...safe } = updated;
    return safe;
};
exports.updateProfile = updateProfile;
const getAddresses = (userId) => db.query(`USER#`, `ADDRESS#`).filter(i => i.ownerId === userId);
exports.getAddresses = getAddresses;
const addAddress = (userId, address) => {
    const id = db.generateId();
    return db.put({
        PK: `USER#${userId}`,
        SK: `ADDRESS#${id}`,
        ownerId: userId,
        addressId: id,
        ...address,
    });
};
exports.addAddress = addAddress;
const updateAddress = (userId, addressId, updates) => {
    const item = db.updateItem(`USER#${userId}`, `ADDRESS#${addressId}`, updates);
    if (!item)
        throw new Error('Address not found');
    return item;
};
exports.updateAddress = updateAddress;
const deleteAddress = (userId, addressId) => {
    const ok = db.deleteItem(`USER#${userId}`, `ADDRESS#${addressId}`);
    if (!ok)
        throw new Error('Address not found');
    return { message: 'Address removed' };
};
exports.deleteAddress = deleteAddress;
const setDefaultAddress = (userId, addressId) => {
    // Unset all defaults first
    const all = db.query(`USER#${userId}`, 'ADDRESS#');
    all.forEach(a => db.updateItem(`USER#${userId}`, a.SK, { isDefault: false }));
    return db.updateItem(`USER#${userId}`, `ADDRESS#${addressId}`, { isDefault: true });
};
exports.setDefaultAddress = setDefaultAddress;
const updatePreferences = (userId, prefs) => {
    const record = db.scan(i => i.SK === 'PROFILE' && i.id === userId)[0];
    if (!record)
        throw new Error('User not found');
    return db.updateItem(record.PK, 'PROFILE', { preferences: prefs });
};
exports.updatePreferences = updatePreferences;
// ─── Admin Users ─────────────────────────────────────────────────────────────
const adminListUsers = () => {
    return db.scan(i => i.SK === 'PROFILE' && i.role === 'customer')
        .map(({ password, ...safe }) => safe);
};
exports.adminListUsers = adminListUsers;
