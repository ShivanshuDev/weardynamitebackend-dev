"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEmployeePayroll = exports.processPayroll = exports.listPayroll = exports.getEmployeeAuditLog = exports.getEmployeeAttendanceHistory = exports.editAttendance = exports.markAttendance = exports.getAttendanceByDate = exports.deleteEmployee = exports.patchEmployeeStatus = exports.updateEmployee = exports.createEmployee = exports.listEmployees = void 0;
const EmployeeService = __importStar(require("./employee.service"));
const listEmployees = (_req, res) => {
    try {
        res.json(EmployeeService.listEmployees());
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.listEmployees = listEmployees;
const createEmployee = (req, res) => {
    try {
        res.status(201).json(EmployeeService.createEmployee(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.createEmployee = createEmployee;
const updateEmployee = (req, res) => {
    try {
        res.json(EmployeeService.updateEmployee(req.params.id, req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateEmployee = updateEmployee;
const patchEmployeeStatus = (req, res) => {
    try {
        res.json(EmployeeService.patchEmployeeStatus(req.params.id, req.body.status));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.patchEmployeeStatus = patchEmployeeStatus;
const deleteEmployee = (req, res) => {
    try {
        res.json(EmployeeService.deleteEmployee(req.params.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.deleteEmployee = deleteEmployee;
// Attendance
const getAttendanceByDate = (req, res) => {
    try {
        res.json(EmployeeService.getAttendanceByDate(req.query.date));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getAttendanceByDate = getAttendanceByDate;
const markAttendance = (req, res) => {
    try {
        res.json(EmployeeService.markAttendance(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.markAttendance = markAttendance;
const editAttendance = (req, res) => {
    try {
        res.json(EmployeeService.markAttendance({ ...req.body, employeeId: req.params.employeeId, date: req.params.date }));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.editAttendance = editAttendance;
const getEmployeeAttendanceHistory = (req, res) => {
    try {
        res.json(EmployeeService.getEmployeeAttendanceHistory(req.params.employeeId));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getEmployeeAttendanceHistory = getEmployeeAttendanceHistory;
const getEmployeeAuditLog = (req, res) => {
    try {
        res.json(EmployeeService.getEmployeeAuditLog(req.params.employeeId));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getEmployeeAuditLog = getEmployeeAuditLog;
// Payroll
const listPayroll = (_req, res) => {
    try {
        res.json(EmployeeService.listPayroll());
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.listPayroll = listPayroll;
const processPayroll = (req, res) => {
    try {
        res.status(201).json(EmployeeService.processPayroll(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.processPayroll = processPayroll;
const getEmployeePayroll = (req, res) => {
    try {
        res.json(EmployeeService.getEmployeePayroll(req.params.employeeId));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getEmployeePayroll = getEmployeePayroll;
