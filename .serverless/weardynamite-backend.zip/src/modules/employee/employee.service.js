"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEmployeePayroll = exports.processPayroll = exports.listPayroll = exports.getEmployeeAuditLog = exports.getEmployeeAttendanceHistory = exports.markAttendance = exports.getAttendanceByDate = exports.deleteEmployee = exports.patchEmployeeStatus = exports.updateEmployee = exports.createEmployee = exports.listEmployees = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const ledger_service_1 = require("../ledger/ledger.service");
// ─── Employees ───────────────────────────────────────────────────────────────
const listEmployees = () => db.scan(i => i.SK === 'EMPLOYEE');
exports.listEmployees = listEmployees;
const createEmployee = (data) => {
    const id = db.generateId();
    return db.put({
        PK: `EMPLOYEE#${id}`,
        SK: 'EMPLOYEE',
        employeeId: id,
        status: 'Active',
        ...data,
    });
};
exports.createEmployee = createEmployee;
const updateEmployee = (id, updates) => {
    const item = db.getItem(`EMPLOYEE#${id}`, 'EMPLOYEE');
    if (!item)
        throw new Error('Employee not found');
    return db.put({ ...item, ...updates, PK: `EMPLOYEE#${id}`, SK: 'EMPLOYEE' });
};
exports.updateEmployee = updateEmployee;
const patchEmployeeStatus = (id, status) => {
    const updated = db.updateItem(`EMPLOYEE#${id}`, 'EMPLOYEE', { status });
    if (!updated)
        throw new Error('Employee not found');
    return updated;
};
exports.patchEmployeeStatus = patchEmployeeStatus;
const deleteEmployee = (id) => {
    const ok = db.deleteItem(`EMPLOYEE#${id}`, 'EMPLOYEE');
    if (!ok)
        throw new Error('Employee not found');
    return { message: 'Employee removed' };
};
exports.deleteEmployee = deleteEmployee;
// ─── Attendance ────────────────────────────────────────────────────────────────
const getAttendanceByDate = (date) => db.scan(i => i.SK?.startsWith('ATTENDANCE#') && i.date === date);
exports.getAttendanceByDate = getAttendanceByDate;
const markAttendance = (data) => {
    const existing = db.getItem(`EMPLOYEE#${data.employeeId}`, `ATTENDANCE#${data.date}`);
    if (existing) {
        // Create audit log before override
        db.put({
            PK: `EMPLOYEE#${data.employeeId}`,
            SK: `AUDIT#${data.date}#${Date.now()}`,
            employeeId: data.employeeId,
            date: data.date,
            oldStatus: existing.status || 'Unknown',
            newStatus: data.status,
            editedBy: data.markedBy || 'admin',
            editType: 'override',
        });
    }
    return db.put({
        PK: `EMPLOYEE#${data.employeeId}`,
        SK: `ATTENDANCE#${data.date}`,
        ...data,
    });
};
exports.markAttendance = markAttendance;
const getEmployeeAttendanceHistory = (employeeId) => db.query(`EMPLOYEE#${employeeId}`, 'ATTENDANCE#')
    .sort((a, b) => b.date.localeCompare(a.date));
exports.getEmployeeAttendanceHistory = getEmployeeAttendanceHistory;
const getEmployeeAuditLog = (employeeId) => db.query(`EMPLOYEE#${employeeId}`, 'AUDIT#')
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
exports.getEmployeeAuditLog = getEmployeeAuditLog;
// ─── Payroll ──────────────────────────────────────────────────────────────────
const listPayroll = () => db.scan(i => i.SK?.startsWith('PAYROLL#'));
exports.listPayroll = listPayroll;
const processPayroll = (data) => {
    const id = db.generateId();
    const employee = db.getItem(`EMPLOYEE#${data.employeeId}`, 'EMPLOYEE');
    if (!employee)
        throw new Error('Employee not found');
    // Auto create ledger debit entry via standardized service
    (0, ledger_service_1.addTransaction)({
        description: `Admin Salary - ${employee.name} (${data.month})`,
        type: 'Debit',
        amount: data.amount,
        referenceId: data.employeeId
    });
    return db.put({
        PK: `EMPLOYEE#${data.employeeId}`,
        SK: `PAYROLL#${data.month}`,
        payrollId: id,
        employeeName: employee.name,
        ...data,
        status: 'Paid',
    });
};
exports.processPayroll = processPayroll;
const getEmployeePayroll = (employeeId) => db.query(`EMPLOYEE#${employeeId}`, 'PAYROLL#');
exports.getEmployeePayroll = getEmployeePayroll;
