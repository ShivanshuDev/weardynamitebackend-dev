"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteExpense = exports.createExpense = exports.listExpenses = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const ledger_service_1 = require("../ledger/ledger.service");
/**
 * List all expenses for admin.
 */
const listExpenses = (filters) => {
    let items = db.scan(i => i.SK === 'EXPENSE');
    if (filters.category) {
        items = items.filter(i => i.category?.toLowerCase() === filters.category.toLowerCase());
    }
    if (filters.dateFrom) {
        items = items.filter(i => (i.date || i.createdAt || '') >= filters.dateFrom);
    }
    if (filters.dateTo) {
        items = items.filter(i => (i.date || i.createdAt || '') <= filters.dateTo);
    }
    return items.sort((a, b) => (b.date || b.createdAt || '').localeCompare(a.date || a.createdAt || ''));
};
exports.listExpenses = listExpenses;
/**
 * Create a new expense and trigger a Ledger entry.
 */
const createExpense = (data) => {
    const id = db.generateId();
    const expenseDate = data.date || new Date().toISOString().split('T')[0];
    const record = db.put({
        PK: `EXPENSE#${id}`,
        SK: 'EXPENSE',
        expenseId: id,
        ...data,
        date: expenseDate,
        status: 'Paid'
    });
    // Automated Financial Propagation: Trigger Ledger Debit
    (0, ledger_service_1.addTransaction)({
        description: `Operational Outflow: ${data.description} (${data.category})`,
        type: 'Debit',
        amount: data.amount
    });
    return record;
};
exports.createExpense = createExpense;
/**
 * Delete an expense record.
 * Note: Decided not to reverse ledger entries for audit compliance (manual adjustment preferred).
 */
const deleteExpense = (id) => {
    const item = db.scan(i => i.expenseId === id)[0];
    if (!item)
        throw new Error('Expense record not found');
    return db.deleteItem(item.PK, item.SK);
};
exports.deleteExpense = deleteExpense;
