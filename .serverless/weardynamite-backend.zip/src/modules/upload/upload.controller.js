"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mockS3Endpoint = exports.deleteFile = exports.requestPresignedUrl = void 0;
const S3Sim_1 = require("../../utils/S3Sim");
const requestPresignedUrl = async (req, res) => {
    try {
        const { fileName, fileType, folder } = req.body;
        if (!fileName || !fileType)
            return res.status(400).json({ message: 'fileName and fileType are required' });
        const result = await (0, S3Sim_1.getPresignedUploadUrl)(fileName, fileType, folder || 'uploads');
        res.json(result);
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.requestPresignedUrl = requestPresignedUrl;
const deleteFile = async (req, res) => {
    try {
        const { fileKey } = req.body;
        if (!fileKey)
            return res.status(400).json({ message: 'fileKey is required' });
        await (0, S3Sim_1.deleteFromS3)(fileKey);
        res.json({ message: 'File deleted successfully' });
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.deleteFile = deleteFile;
// Mock S3 upload endpoint (dev only — accepts the upload and returns 200)
const mockS3Endpoint = (req, res) => {
    res.status(200).json({ message: 'Mock S3 upload accepted', key: req.query.key });
};
exports.mockS3Endpoint = mockS3Endpoint;
