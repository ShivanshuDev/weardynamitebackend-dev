"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportSubscribersCSV = exports.listSubscribers = exports.unsubscribe = exports.subscribe = exports.getInquiryDetail = exports.deleteInquiry = exports.updateInquiryStatus = exports.listInquiries = exports.submitInquiry = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
// ─── Inquiries ────────────────────────────────────────────────────────────────
const submitInquiry = (data) => {
    const id = db.generateId();
    return db.put({ PK: `INQUIRY#${id}`, SK: 'INQUIRY', inquiryId: id, status: 'New', ...data });
};
exports.submitInquiry = submitInquiry;
const listInquiries = (status) => {
    let items = db.scan(i => i.SK === 'INQUIRY');
    if (status)
        items = items.filter(i => i.status === status);
    return items.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};
exports.listInquiries = listInquiries;
const updateInquiryStatus = (id, status) => {
    const updated = db.updateItem(`INQUIRY#${id}`, 'INQUIRY', { status });
    if (!updated)
        throw new Error('Inquiry not found');
    return updated;
};
exports.updateInquiryStatus = updateInquiryStatus;
const deleteInquiry = (id) => {
    db.deleteItem(`INQUIRY#${id}`, 'INQUIRY');
    return { message: 'Inquiry archived' };
};
exports.deleteInquiry = deleteInquiry;
const getInquiryDetail = (id) => {
    const item = db.getItem(`INQUIRY#${id}`, 'INQUIRY');
    if (!item)
        throw new Error('Inquiry not found');
    return item;
};
exports.getInquiryDetail = getInquiryDetail;
// ─── Subscribers ──────────────────────────────────────────────────────────────
const subscribe = (email) => {
    const existing = db.getItem(`SUBSCRIBER#${email.toLowerCase()}`, 'SUBSCRIBER');
    if (existing)
        return { message: 'Already subscribed' };
    return db.put({ PK: `SUBSCRIBER#${email.toLowerCase()}`, SK: 'SUBSCRIBER', email: email.toLowerCase(), status: 'Active' });
};
exports.subscribe = subscribe;
const unsubscribe = (email) => {
    db.updateItem(`SUBSCRIBER#${email.toLowerCase()}`, 'SUBSCRIBER', { status: 'Unsubscribed' });
    return { message: 'Unsubscribed successfully' };
};
exports.unsubscribe = unsubscribe;
const listSubscribers = () => db.scan(i => i.SK === 'SUBSCRIBER' && i.status === 'Active');
exports.listSubscribers = listSubscribers;
const exportSubscribersCSV = () => {
    const subscribers = (0, exports.listSubscribers)();
    const csv = ['email,joinedDate', ...subscribers.map(s => `${s.email},${s.createdAt || ''}`)].join('\n');
    return csv;
};
exports.exportSubscribersCSV = exportSubscribersCSV;
