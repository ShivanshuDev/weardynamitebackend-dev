"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetPassword = exports.forgotPassword = exports.adminLogin = exports.login = exports.register = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const db = __importStar(require("../../utils/DynamoSim"));
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const signToken = (payload) => jsonwebtoken_1.default.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
// ─── Customer Auth ───────────────────────────────────────────────────────────
const register = async (name, email, password) => {
    const existing = db.getItem(`USER#${email.toLowerCase()}`, 'PROFILE');
    if (existing)
        throw new Error('Email already registered');
    const hash = await bcryptjs_1.default.hash(password, 10);
    const user = db.put({
        PK: `USER#${email.toLowerCase()}`,
        SK: 'PROFILE',
        name,
        email: email.toLowerCase(),
        password: hash,
        role: 'customer',
        joinedDate: new Date().toISOString(),
    });
    const { password: _, ...safeUser } = user;
    const token = signToken({ id: user.id, email: user.email, role: user.role });
    return { user: safeUser, token };
};
exports.register = register;
const login = async (email, password) => {
    const user = db.getItem(`USER#${email.toLowerCase()}`, 'PROFILE');
    if (!user)
        throw new Error('Invalid credentials');
    const match = await bcryptjs_1.default.compare(password, user.password);
    if (!match)
        throw new Error('Invalid credentials');
    const { password: _, ...safeUser } = user;
    const token = signToken({ id: user.id, email: user.email, role: user.role });
    return { user: safeUser, token };
};
exports.login = login;
// ─── Admin Auth ───────────────────────────────────────────────────────────────
const adminLogin = async (email, password) => {
    // Seed default admin if not exists
    const existing = db.getItem(`ADMIN#${email.toLowerCase()}`, 'PROFILE');
    if (!existing) {
        // Auto-seed admin account on first login attempt
        const hash = await bcryptjs_1.default.hash('admin123', 10);
        db.put({ PK: `ADMIN#admin@weardynamite.com`, SK: 'PROFILE', name: 'Super Admin', email: 'admin@weardynamite.com', password: hash, role: 'admin' });
        if (email.toLowerCase() !== 'admin@weardynamite.com')
            throw new Error('Invalid admin credentials');
    }
    const admin = db.getItem(`ADMIN#${email.toLowerCase()}`, 'PROFILE');
    if (!admin)
        throw new Error('Invalid admin credentials');
    const match = await bcryptjs_1.default.compare(password, admin.password);
    if (!match)
        throw new Error('Invalid admin credentials');
    const { password: _, ...safeAdmin } = admin;
    const token = signToken({ id: admin.id, email: admin.email, role: 'admin' });
    return { admin: safeAdmin, token };
};
exports.adminLogin = adminLogin;
// ─── Password Reset (OTP-based, mocked) ─────────────────────────────────────
const forgotPassword = async (email) => {
    const user = db.getItem(`USER#${email.toLowerCase()}`, 'PROFILE');
    if (!user)
        throw new Error('No account found with this email');
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    db.updateItem(`USER#${email.toLowerCase()}`, 'PROFILE', { resetOtp: otp, otpExpiry: Date.now() + 10 * 60 * 1000 });
    // In production: send OTP via email (SES / nodemailer)
    console.log(`[AUTH] OTP for ${email}: ${otp}`);
    return { message: 'OTP sent to email (check server console in dev mode)' };
};
exports.forgotPassword = forgotPassword;
const resetPassword = async (email, otp, newPassword) => {
    const user = db.getItem(`USER#${email.toLowerCase()}`, 'PROFILE');
    if (!user || user.resetOtp !== otp)
        throw new Error('Invalid OTP');
    if (Date.now() > user.otpExpiry)
        throw new Error('OTP expired');
    const hash = await bcryptjs_1.default.hash(newPassword, 10);
    db.updateItem(`USER#${email.toLowerCase()}`, 'PROFILE', { password: hash, resetOtp: null, otpExpiry: null });
    return { message: 'Password reset successfully' };
};
exports.resetPassword = resetPassword;
