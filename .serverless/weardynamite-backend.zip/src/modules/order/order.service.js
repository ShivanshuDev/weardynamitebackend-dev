"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOrderTracking = exports.updateOrderStatus = exports.getOrderDetail = exports.adminListOrders = exports.getUserOrder = exports.getUserOrders = exports.placeOrder = exports.toggleFavorite = exports.getFavorites = exports.clearCart = exports.removeCartItem = exports.updateCartItem = exports.addToCart = exports.getCart = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const ledger_service_1 = require("../ledger/ledger.service");
// ─── Cart ────────────────────────────────────────────────────────────────────
const getCart = (userId) => db.query(`USER#${userId}`, 'CART#');
exports.getCart = getCart;
const addToCart = (userId, item) => {
    const itemKey = `${item.productId}-${item.color}-${item.size}`;
    return db.put({
        PK: `USER#${userId}`,
        SK: `CART#${itemKey}`,
        ...item,
        ownerId: userId,
    });
};
exports.addToCart = addToCart;
const updateCartItem = (userId, itemId, quantity) => {
    const updated = db.updateItem(`USER#${userId}`, `CART#${itemId}`, { quantity });
    if (!updated)
        throw new Error('Cart item not found');
    return updated;
};
exports.updateCartItem = updateCartItem;
const removeCartItem = (userId, itemId) => {
    db.deleteItem(`USER#${userId}`, `CART#${itemId}`);
    return { message: 'Item removed from cart' };
};
exports.removeCartItem = removeCartItem;
const clearCart = (userId) => {
    const items = db.query(`USER#${userId}`, 'CART#');
    items.forEach(i => db.deleteItem(i.PK, i.SK));
    return { message: 'Cart cleared' };
};
exports.clearCart = clearCart;
// ─── Favorites ───────────────────────────────────────────────────────────────
const getFavorites = (userId) => db.query(`USER#${userId}`, 'FAVORITE#');
exports.getFavorites = getFavorites;
const toggleFavorite = (userId, productId) => {
    const existing = db.getItem(`USER#${userId}`, `FAVORITE#${productId}`);
    if (existing) {
        db.deleteItem(`USER#${userId}`, `FAVORITE#${productId}`);
        return { favorited: false };
    }
    else {
        db.put({ PK: `USER#${userId}`, SK: `FAVORITE#${productId}`, productId, ownerId: userId });
        return { favorited: true };
    }
};
exports.toggleFavorite = toggleFavorite;
// ─── Orders ──────────────────────────────────────────────────────────────────
const placeOrder = (userId, orderData) => {
    const { addressId, paymentMethod, items, couponCode } = orderData;
    if (!items?.length)
        throw new Error('No items in order');
    const orderId = db.generateId();
    const orderNumber = `ORD-${Date.now().toString().slice(-6)}`;
    // Calculate total exactly from DB with promotion logic
    let subtotal = 0;
    let discountTotal = 0;
    let taxTotal = 0;
    // 1) Group items for promotion logic
    const groupedItems = items.reduce((acc, item) => {
        if (!acc[item.productId])
            acc[item.productId] = [];
        acc[item.productId].push(item);
        return acc;
    }, {});
    const itemsWithPrice = [];
    // 2) Process each product group
    Object.keys(groupedItems).forEach(productId => {
        const productItems = groupedItems[productId];
        const product = db.getItem(`PRODUCT#${productId}`, 'PRODUCT');
        if (!product)
            throw new Error(`Product ${productId} not found`);
        const basePrice = product.salePrice || product.mrp || 0;
        const discountPercent = product.discountPercentage || 0;
        const discountedPrice = basePrice * (1 - discountPercent / 100);
        const totalQty = productItems.reduce((s, i) => s + i.quantity, 0);
        let productSubtotal = 0;
        let productDiscount = 0;
        productItems.forEach((item) => {
            const itemSubtotal = basePrice * item.quantity;
            productSubtotal += itemSubtotal;
            productDiscount += (basePrice - discountedPrice) * item.quantity;
            itemsWithPrice.push({ ...item, price: basePrice, discountedPrice });
        });
        // Buy X Get Y logic
        if (product.promotionType === 'B1G1') {
            productDiscount += Math.floor(totalQty / 2) * discountedPrice;
        }
        else if (product.promotionType === 'B2G1') {
            productDiscount += Math.floor(totalQty / 3) * discountedPrice;
        }
        subtotal += productSubtotal;
        discountTotal += productDiscount;
        // Tax logic (applied on product-level discounted amount)
        if (product.isTaxable !== false) {
            const taxableAmount = productSubtotal - productDiscount;
            taxTotal += taxableAmount * ((product.taxPercent || 12) / 100);
        }
    });
    // 3) Coupon logic (15% if coupon applied)
    if (couponCode) {
        discountTotal += (subtotal - discountTotal) * 0.15;
    }
    // 4) First time user discount (10%)
    const userOrders = db.query(`USER#${userId}`, 'ORDER');
    if (userOrders.length === 0) {
        discountTotal += (subtotal - discountTotal) * 0.10;
    }
    const shipping = subtotal > 5000 ? 0 : 150;
    const totalAmount = Math.round((subtotal - discountTotal + shipping + taxTotal) * 100) / 100;
    let stockError;
    const result = db.transactWrite([
        // 1) Create order record
        () => db.put({
            PK: `USER#${userId}`,
            SK: `ORDER#${orderId}`,
            orderId,
            orderNumber,
            userId,
            addressId,
            paymentMethod,
            status: 'Pending',
            items: itemsWithPrice,
            totalAmount,
            couponCode,
            trackingNumber: null,
            courier: null,
        }),
        // 2) Decrement stock for each item
        ...items.map((item) => () => {
            const res = db.conditionalUpdate(`PRODUCT#${item.productId}`, 'PRODUCT', (p) => {
                const cv = (p.variants || []).find((v) => v.color === item.color);
                const se = cv?.sizes?.find((s) => s.size === item.size);
                return se && se.stock >= item.quantity;
            }, {
                variants: (() => {
                    const product = db.getItem(`PRODUCT#${item.productId}`, 'PRODUCT');
                    if (!product) {
                        stockError = `Product ${item.productId} not found`;
                        throw new Error(stockError);
                    }
                    return (product.variants || []).map((v) => v.color === item.color
                        ? { ...v, sizes: v.sizes.map((s) => s.size === item.size ? { ...s, stock: s.stock - item.quantity } : s) }
                        : v);
                })(),
            });
            if (!res.success) {
                const product = db.getItem(`PRODUCT#${item.productId}`, 'PRODUCT');
                stockError = `Insufficient stock for ${product?.name || item.productId} (${item.color}, ${item.size})`;
                throw new Error(stockError);
            }
        }),
    ]);
    if (!result.success)
        throw new Error(result.error || stockError || 'Order failed');
    // Automated Financial Propagation: Trigger Ledger Credit on Order Placement
    (0, ledger_service_1.addTransaction)({
        description: `Order Revenue (New): ${orderNumber}`,
        type: 'Credit',
        amount: totalAmount,
        referenceId: orderId
    });
    return { orderId, orderNumber, totalAmount, status: 'Pending' };
};
exports.placeOrder = placeOrder;
const getUserOrders = (userId) => db.query(`USER#${userId}`, 'ORDER#').sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
exports.getUserOrders = getUserOrders;
const getUserOrder = (userId, orderId) => {
    const item = db.getItem(`USER#${userId}`, `ORDER#${orderId}`);
    if (!item)
        throw new Error('Order not found');
    return item;
};
exports.getUserOrder = getUserOrder;
// ─── Admin Orders ─────────────────────────────────────────────────────────────
const adminListOrders = (filters) => {
    let orders = db.scan(i => i.SK?.startsWith('ORDER#'));
    // Enrich orders with customer and address data FIRST for searching
    const enriched = orders.map(order => {
        const customer = db.scan(i => i.SK === 'PROFILE' && i.id === order.userId)[0];
        const address = db.scan(i => i.PK === `USER#${order.userId}` && i.SK?.startsWith('ADDRESS#'))[0];
        return {
            ...order,
            customer: customer ? { name: customer.name, email: customer.email, phone: customer.phone } : null,
            address: address ? { street: address.street, city: address.city, state: address.state, zip: address.zip, country: address.country } : null
        };
    });
    let result = enriched;
    if (filters.status)
        result = result.filter(o => o.status === filters.status);
    if (filters.customerId)
        result = result.filter(o => o.userId === filters.customerId);
    if (filters.date)
        result = result.filter(o => o.createdAt?.startsWith(filters.date));
    if (filters.search) {
        const q = filters.search.toLowerCase();
        result = result.filter(o => o.id?.toLowerCase().includes(q) ||
            o.orderNumber?.toLowerCase().includes(q) ||
            (o.customer?.name || '').toLowerCase().includes(q) ||
            (o.customer?.email || '').toLowerCase().includes(q) ||
            (o.customer?.phone || '').toLowerCase().includes(q));
    }
    return result.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};
exports.adminListOrders = adminListOrders;
const getOrderDetail = (orderId) => {
    const item = db.scan(i => i.SK === `ORDER#${orderId}` || i.orderId === orderId)[0];
    if (!item)
        throw new Error('Order not found');
    const customer = db.scan(i => i.SK === 'PROFILE' && i.id === item.userId)[0];
    const address = db.scan(i => i.PK === `USER#${item.userId}` && i.SK?.startsWith('ADDRESS#'))[0];
    return {
        ...item,
        customer: customer ? { name: customer.name, email: customer.email, phone: customer.phone } : null,
        address: address ? { street: address.street, city: address.city, state: address.state, zip: address.zip, country: address.country } : null
    };
};
exports.getOrderDetail = getOrderDetail;
const updateOrderStatus = (orderId, status) => {
    const order = db.scan(i => i.orderId === orderId)[0];
    if (!order)
        throw new Error('Order not found');
    const updated = db.updateItem(order.PK, order.SK, { status });
    // Automated Financial Propagation: Trigger Ledger Credit on Delivery
    if (status === 'Delivered') {
        (0, ledger_service_1.addTransaction)({
            description: `Order Revenue: ${order.orderNumber || orderId}`,
            type: 'Credit',
            amount: order.totalAmount || 0,
            referenceId: orderId
        });
    }
    return updated;
};
exports.updateOrderStatus = updateOrderStatus;
const updateOrderTracking = (orderId, trackingNumber, courier) => {
    const order = db.scan(i => i.orderId === orderId)[0];
    if (!order)
        throw new Error('Order not found');
    return db.updateItem(order.PK, order.SK, { trackingNumber, courier, status: 'Shipped' });
};
exports.updateOrderTracking = updateOrderTracking;
