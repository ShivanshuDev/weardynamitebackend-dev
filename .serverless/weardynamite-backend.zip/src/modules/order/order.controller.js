"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInvoice = exports.updateOrderTracking = exports.updateOrderStatus = exports.getOrderDetail = exports.adminListOrders = exports.getUserOrder = exports.getUserOrders = exports.placeOrder = exports.toggleFavorite = exports.getFavorites = exports.clearCart = exports.removeCartItem = exports.updateCartItem = exports.addToCart = exports.getCart = void 0;
const OrderService = __importStar(require("./order.service"));
// Cart
const getCart = (req, res) => {
    try {
        res.json(OrderService.getCart(req.user.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getCart = getCart;
const addToCart = (req, res) => {
    try {
        res.status(201).json(OrderService.addToCart(req.user.id, req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.addToCart = addToCart;
const updateCartItem = (req, res) => {
    try {
        res.json(OrderService.updateCartItem(req.user.id, req.params.itemId, req.body.quantity));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateCartItem = updateCartItem;
const removeCartItem = (req, res) => {
    try {
        res.json(OrderService.removeCartItem(req.user.id, req.params.itemId));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.removeCartItem = removeCartItem;
const clearCart = (req, res) => {
    try {
        res.json(OrderService.clearCart(req.user.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.clearCart = clearCart;
// Favorites
const getFavorites = (req, res) => {
    try {
        res.json(OrderService.getFavorites(req.user.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getFavorites = getFavorites;
const toggleFavorite = (req, res) => {
    try {
        res.json(OrderService.toggleFavorite(req.user.id, req.params.productId));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.toggleFavorite = toggleFavorite;
// Orders (customer)
const placeOrder = (req, res) => {
    try {
        res.status(201).json(OrderService.placeOrder(req.user.id, req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.placeOrder = placeOrder;
const getUserOrders = (req, res) => {
    try {
        res.json(OrderService.getUserOrders(req.user.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getUserOrders = getUserOrders;
const getUserOrder = (req, res) => {
    try {
        res.json(OrderService.getUserOrder(req.user.id, req.params.id));
    }
    catch (e) {
        res.status(404).json({ message: e.message });
    }
};
exports.getUserOrder = getUserOrder;
// Admin orders
const adminListOrders = (req, res) => {
    try {
        res.json(OrderService.adminListOrders(req.query));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.adminListOrders = adminListOrders;
const getOrderDetail = (req, res) => {
    try {
        res.json(OrderService.getOrderDetail(req.params.id));
    }
    catch (e) {
        res.status(404).json({ message: e.message });
    }
};
exports.getOrderDetail = getOrderDetail;
const updateOrderStatus = (req, res) => {
    try {
        res.json(OrderService.updateOrderStatus(req.params.id, req.body.status));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateOrderStatus = updateOrderStatus;
const updateOrderTracking = (req, res) => {
    try {
        res.json(OrderService.updateOrderTracking(req.params.id, req.body.trackingNumber, req.body.courier));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateOrderTracking = updateOrderTracking;
const getInvoice = (req, res) => {
    try {
        res.json({ invoice: OrderService.getOrderDetail(req.params.id) });
    }
    catch (e) {
        res.status(404).json({ message: e.message });
    }
};
exports.getInvoice = getInvoice;
