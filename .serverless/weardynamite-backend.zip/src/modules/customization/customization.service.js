"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateCustomOrderStatus = exports.listCustomOrders = exports.submitDesignStudioOrder = exports.submitEmbroideryCustomization = exports.submitPrintCustomization = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
// ─── Custom Order Submission ──────────────────────────────────────────────────
const createCustomOrder = (type, data) => {
    const id = db.generateId();
    return db.put({
        PK: `CUSTOM#${id}`,
        SK: 'CUSTOM',
        customId: id,
        type,
        status: 'Pending Review',
        ...data,
    });
};
const submitPrintCustomization = (data) => createCustomOrder('Print', data);
exports.submitPrintCustomization = submitPrintCustomization;
const submitEmbroideryCustomization = (data) => createCustomOrder('Embroidery', data);
exports.submitEmbroideryCustomization = submitEmbroideryCustomization;
const submitDesignStudioOrder = (data) => createCustomOrder('DesignStudio', data);
exports.submitDesignStudioOrder = submitDesignStudioOrder;
const listCustomOrders = (filters) => {
    let items = db.scan(i => i.SK === 'CUSTOM');
    if (filters?.status)
        items = items.filter(i => i.status === filters.status);
    if (filters?.type)
        items = items.filter(i => i.type === filters.type);
    return items.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};
exports.listCustomOrders = listCustomOrders;
const updateCustomOrderStatus = (id, status) => {
    const updated = db.updateItem(`CUSTOM#${id}`, 'CUSTOM', { status });
    if (!updated)
        throw new Error('Custom order not found');
    return updated;
};
exports.updateCustomOrderStatus = updateCustomOrderStatus;
