"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateInventory = exports.deleteProduct = exports.patchProductStatus = exports.updateProduct = exports.createProduct = exports.getBestSellers = exports.getNewArrivals = exports.getProduct = exports.searchProducts = exports.listProducts = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
// ─── Public: Read Product(s) ─────────────────────────────────────────────────
const listProducts = (filters) => {
    const { category, subCategory, sort = 'createdAt_desc', page = 1, limit = 10, status, color, fit, neckType, occasion } = filters;
    let items = db.scan(i => i.SK === 'PRODUCT');
    if (category)
        items = items.filter(i => i.category === category);
    if (subCategory)
        items = items.filter(i => i.subCategory === subCategory);
    if (status)
        items = items.filter(i => i.status === status);
    if (color)
        items = items.filter(i => i.primaryColor === color || (i.variants || []).some((v) => v.color === color));
    if (fit)
        items = items.filter(i => i.fit === fit);
    if (neckType)
        items = items.filter(i => i.neckType === neckType);
    if (occasion)
        items = items.filter(i => i.occasion === occasion);
    // Sort
    const [sortField, sortDir] = sort.split('_');
    items.sort((a, b) => {
        const av = a[sortField] ?? '';
        const bv = b[sortField] ?? '';
        return sortDir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });
    const total = items.length;
    const start = (page - 1) * limit;
    const paginatedItems = items.slice(start, start + limit).map(i => ({ ...i, id: i.productId }));
    return { items: paginatedItems, total, page, limit, totalPages: Math.ceil(total / limit) };
};
exports.listProducts = listProducts;
const searchProducts = (q) => {
    const lower = q.toLowerCase();
    return db.scan(i => i.SK === 'PRODUCT' && (i.name?.toLowerCase().includes(lower) ||
        i.sku?.toLowerCase().includes(lower) ||
        i.category?.toLowerCase().includes(lower) ||
        i.subCategory?.toLowerCase().includes(lower) ||
        i.primaryColor?.toLowerCase().includes(lower) ||
        i.occasion?.toLowerCase().includes(lower) ||
        (i.keywords || []).some((k) => k.toLowerCase().includes(lower)))).map(i => ({ ...i, id: i.productId }));
};
exports.searchProducts = searchProducts;
const getProduct = (id) => {
    const item = db.getItem(`PRODUCT#${id}`, 'PRODUCT');
    if (!item)
        throw new Error('Product not found');
    return { ...item, id: item.productId };
};
exports.getProduct = getProduct;
const getNewArrivals = () => db.queryGSI('isNewArrival', true, 'createdAt', 'desc').slice(0, 12).map(i => ({ ...i, id: i.productId }));
exports.getNewArrivals = getNewArrivals;
const getBestSellers = () => db.queryGSI('isBestSeller', true, 'salesCount', 'desc').slice(0, 12).map(i => ({ ...i, id: i.productId }));
exports.getBestSellers = getBestSellers;
// ─── Admin: Full CRUD ────────────────────────────────────────────────────────
const createProduct = (data) => {
    const id = db.generateId();
    return db.put({
        PK: `PRODUCT#${id}`,
        SK: 'PRODUCT',
        productId: id,
        category: data.category || '',
        status: 'Active',
        salesCount: 0,
        isNewArrival: true,
        isBestSeller: false,
        ...data,
    });
};
exports.createProduct = createProduct;
const updateProduct = (id, updates) => {
    const existing = db.getItem(`PRODUCT#${id}`, 'PRODUCT');
    if (!existing)
        throw new Error('Product not found');
    return db.put({ ...existing, ...updates, PK: `PRODUCT#${id}`, SK: 'PRODUCT' });
};
exports.updateProduct = updateProduct;
const patchProductStatus = (id, status) => {
    const updated = db.updateItem(`PRODUCT#${id}`, 'PRODUCT', { status });
    if (!updated)
        throw new Error('Product not found');
    return updated;
};
exports.patchProductStatus = patchProductStatus;
const deleteProduct = (id) => {
    const ok = db.deleteItem(`PRODUCT#${id}`, 'PRODUCT');
    if (!ok)
        throw new Error('Product not found');
    return { message: 'Product deleted' };
};
exports.deleteProduct = deleteProduct;
const updateInventory = (id, colorVariant, size, delta, mode = 'relative') => {
    const product = db.getItem(`PRODUCT#${id}`, 'PRODUCT');
    if (!product)
        throw new Error('Product not found');
    const variants = product.variants || [];
    const colorGroup = variants.find((v) => v.color === colorVariant);
    if (!colorGroup)
        throw new Error('Color variant not found');
    const sizeEntry = colorGroup.sizes.find((s) => s.size === size);
    if (!sizeEntry)
        throw new Error('Size not found');
    if (mode === 'relative') {
        const result = db.conditionalUpdate(`PRODUCT#${id}`, 'PRODUCT', item => {
            const cv = (item.variants || []).find((v) => v.color === colorVariant);
            const se = cv?.sizes?.find((s) => s.size === size);
            return se && (se.stock + delta) >= 0;
        }, { variants: variants.map((v) => v.color === colorVariant
                ? { ...v, sizes: v.sizes.map((s) => s.size === size ? { ...s, stock: s.stock + delta } : s) }
                : v) });
        if (!result.success)
            throw new Error('Insufficient stock');
        return result.item;
    }
    else {
        sizeEntry.stock = delta;
        return db.updateItem(`PRODUCT#${id}`, 'PRODUCT', { variants });
    }
};
exports.updateInventory = updateInventory;
