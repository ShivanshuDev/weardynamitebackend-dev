"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteInventoryInvoice = exports.createInventoryInvoice = exports.listInventoryInvoices = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
const listInventoryInvoices = (filters = {}) => {
    let items = db.scan(i => i.SK?.startsWith('INVOICE#'));
    if (filters.vendorId)
        items = items.filter(i => i.vendorId === filters.vendorId);
    return items.sort((a, b) => (b.invoiceDate || '').localeCompare(a.invoiceDate || ''));
};
exports.listInventoryInvoices = listInventoryInvoices;
const createInventoryInvoice = (data) => {
    const invoiceId = db.generateId();
    // 1. Store the Invoice Record
    db.put({
        PK: `INVOICE#${invoiceId}`,
        SK: 'INVOICE',
        invoiceId,
        status: 'Active',
        ...data
    });
    // 2. Batch Update Product Stock (Atomic increment would be better, but DynamoSim uses put)
    data.items.forEach(item => {
        const product = db.getItem(`PRODUCT#${item.productId}`, 'PRODUCT');
        if (product) {
            const updatedVariants = (product.variants || []).map((v) => {
                const matchingIncoming = item.variants.find((iv) => iv.color === v.color);
                if (matchingIncoming) {
                    return {
                        ...v,
                        sizes: v.sizes.map((s) => {
                            const szIncoming = matchingIncoming.sizes.find((is) => is.size === s.size);
                            return szIncoming ? { ...s, stock: (s.stock || 0) + szIncoming.quantity } : s;
                        })
                    };
                }
                return v;
            });
            db.updateItem(`PRODUCT#${item.productId}`, 'PRODUCT', {
                variants: updatedVariants,
                status: 'Active' // Ensure product is active if stock is added
            });
        }
    });
    return { invoiceId, message: 'Stock successfully synchronized' };
};
exports.createInventoryInvoice = createInventoryInvoice;
const deleteInventoryInvoice = (id) => {
    const ok = db.deleteItem(`INVOICE#${id}`, 'INVOICE');
    if (!ok)
        throw new Error('Invoice not found');
    return { message: 'Invoice trace removed' };
};
exports.deleteInventoryInvoice = deleteInventoryInvoice;
