"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateInventory = exports.deleteInventoryInvoice = exports.createInventoryInvoice = exports.listInventoryInvoices = exports.deleteProduct = exports.patchProductStatus = exports.updateProduct = exports.createProduct = exports.getBestSellers = exports.getNewArrivals = exports.getProduct = exports.searchProducts = exports.listProducts = void 0;
const ProductService = __importStar(require("./product.service"));
const InventoryService = __importStar(require("./inventory.service"));
const listProducts = (req, res) => {
    try {
        const { category, subCategory, sort, page, limit, status, color, fit, neckType, occasion } = req.query;
        res.json(ProductService.listProducts({ category, subCategory, sort, page: Number(page) || 1, limit: Number(limit) || 10, status, color, fit, neckType, occasion }));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.listProducts = listProducts;
const searchProducts = (req, res) => {
    try {
        res.json(ProductService.searchProducts(req.query.q || ''));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.searchProducts = searchProducts;
const getProduct = (req, res) => {
    try {
        res.json(ProductService.getProduct(req.params.id));
    }
    catch (e) {
        res.status(404).json({ message: e.message });
    }
};
exports.getProduct = getProduct;
const getNewArrivals = (_req, res) => res.json(ProductService.getNewArrivals());
exports.getNewArrivals = getNewArrivals;
const getBestSellers = (_req, res) => res.json(ProductService.getBestSellers());
exports.getBestSellers = getBestSellers;
const createProduct = (req, res) => {
    try {
        res.status(201).json(ProductService.createProduct(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.createProduct = createProduct;
const updateProduct = (req, res) => {
    try {
        res.json(ProductService.updateProduct(req.params.id, req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateProduct = updateProduct;
const patchProductStatus = (req, res) => {
    try {
        res.json(ProductService.patchProductStatus(req.params.id, req.body.status));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.patchProductStatus = patchProductStatus;
const deleteProduct = (req, res) => {
    try {
        res.json(ProductService.deleteProduct(req.params.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.deleteProduct = deleteProduct;
// ─── Inventory Invoices ───────────────────────────────────────────────────────
const listInventoryInvoices = (req, res) => {
    try {
        res.json(InventoryService.listInventoryInvoices({ vendorId: req.query.vendorId }));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.listInventoryInvoices = listInventoryInvoices;
const createInventoryInvoice = (req, res) => {
    try {
        res.status(201).json(InventoryService.createInventoryInvoice(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.createInventoryInvoice = createInventoryInvoice;
const deleteInventoryInvoice = (req, res) => {
    try {
        res.json(InventoryService.deleteInventoryInvoice(req.params.id));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.deleteInventoryInvoice = deleteInventoryInvoice;
const updateInventory = (req, res) => {
    try {
        const { color, size, delta, mode } = req.body;
        res.json(ProductService.updateInventory(req.params.id, color, size, Number(delta), mode));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.updateInventory = updateInventory;
