"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTopProducts = exports.getRevenueChart = exports.getDashboardStats = exports.exportLedgerCSV = exports.getLedgerSummary = exports.getDailySummary = exports.addTransaction = exports.listTransactions = void 0;
const db = __importStar(require("../../utils/DynamoSim"));
// ─── Ledger ───────────────────────────────────────────────────────────────────
const listTransactions = (filters) => {
    let items = db.scan(i => i.SK === 'LEDGER');
    if (filters.type)
        items = items.filter(i => i.type === filters.type);
    if (filters.dateFrom)
        items = items.filter(i => (i.createdAt || '') >= filters.dateFrom);
    if (filters.dateTo)
        items = items.filter(i => (i.createdAt || '') <= filters.dateTo);
    return items.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};
exports.listTransactions = listTransactions;
const addTransaction = (data) => {
    const id = db.generateId();
    const date = data.date || new Date().toISOString().split('T')[0];
    return db.put({
        PK: `LEDGER#${id}`,
        SK: 'LEDGER',
        ledgerId: id,
        ...data,
        date // Ensure date is explicitly stored for daily filtering
    });
};
exports.addTransaction = addTransaction;
const getDailySummary = (date) => {
    const allItems = db.scan(i => i.SK === 'LEDGER');
    // 1. Opening Balance: All transactions before the selected date
    const beforeItems = allItems.filter(i => (i.date || i.createdAt || '') < date);
    const openingCredit = beforeItems.filter(i => i.type === 'Credit').reduce((s, i) => s + Number(i.amount), 0);
    const openingDebit = beforeItems.filter(i => i.type === 'Debit').reduce((s, i) => s + Number(i.amount), 0);
    const openingBalance = openingCredit - openingDebit;
    // 2. Today's Activity: Transactions on the target date
    const todayItems = allItems.filter(i => (i.date || i.createdAt || '').startsWith(date));
    const todayCredit = todayItems.filter(i => i.type === 'Credit').reduce((s, i) => s + Number(i.amount), 0);
    const todayDebit = todayItems.filter(i => i.type === 'Debit').reduce((s, i) => s + Number(i.amount), 0);
    // 3. Closing Balance
    const closingBalance = openingBalance + todayCredit - todayDebit;
    return {
        date,
        openingBalance,
        todayCredit,
        todayDebit,
        netChange: todayCredit - todayDebit,
        closingBalance,
        transactionCount: todayItems.length
    };
};
exports.getDailySummary = getDailySummary;
const getLedgerSummary = () => {
    const items = db.scan(i => i.SK === 'LEDGER');
    const totalCredit = items.filter(i => i.type === 'Credit').reduce((s, i) => s + Number(i.amount), 0);
    const totalDebit = items.filter(i => i.type === 'Debit').reduce((s, i) => s + Number(i.amount), 0);
    return { totalCredit, totalDebit, netProfit: totalCredit - totalDebit };
};
exports.getLedgerSummary = getLedgerSummary;
const exportLedgerCSV = () => {
    const items = (0, exports.listTransactions)({});
    const csv = ['id,description,type,amount,date', ...items.map(i => `${i.ledgerId},"${i.description}",${i.type},${i.amount},${i.createdAt || ''}`)].join('\n');
    return csv;
};
exports.exportLedgerCSV = exportLedgerCSV;
// ─── Dashboard ────────────────────────────────────────────────────────────────
const getDashboardStats = () => {
    const orders = db.scan(i => i.SK?.startsWith('ORDER#'));
    const products = db.scan(i => i.SK === 'PRODUCT');
    const todayStr = new Date().toISOString().split('T')[0];
    const todaysOrders = orders.filter(o => o.createdAt?.startsWith(todayStr));
    const todaysRevenue = todaysOrders.reduce((s, o) => s + Number(o.totalAmount || 0), 0);
    return {
        todaysRevenue,
        totalOrders: orders.length,
        pendingOrders: orders.filter(o => o.status === 'Pending').length,
        processingOrders: orders.filter(o => o.status === 'Processing').length,
        shippedOrders: orders.filter(o => o.status === 'Shipped').length,
        deliveredOrders: orders.filter(o => o.status === 'Delivered').length,
        totalProducts: products.length,
        activeProducts: products.filter(p => p.status === 'Active').length,
        totalEmployees: db.scan(i => i.SK === 'EMPLOYEE').length,
    };
};
exports.getDashboardStats = getDashboardStats;
const getRevenueChart = (period) => {
    const orders = db.scan(i => i.SK?.startsWith('ORDER#'));
    const days = period === '7d' ? 7 : period === '90d' ? 90 : 30;
    const result = {};
    for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().split('T')[0];
        result[key] = 0;
    }
    orders.forEach(o => {
        const day = o.createdAt?.split('T')[0];
        if (day && result[day] !== undefined)
            result[day] += Number(o.totalAmount || 0);
    });
    return Object.entries(result).map(([date, revenue]) => ({ date, revenue }));
};
exports.getRevenueChart = getRevenueChart;
const getTopProducts = () => {
    const products = db.scan(i => i.SK === 'PRODUCT');
    return products.sort((a, b) => Number(b.salesCount || 0) - Number(a.salesCount || 0)).slice(0, 5);
};
exports.getTopProducts = getTopProducts;
