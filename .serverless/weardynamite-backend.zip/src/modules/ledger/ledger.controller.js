"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTopProducts = exports.getRevenueChart = exports.getDashboardStats = exports.exportLedger = exports.getDailyLedger = exports.getLedgerSummary = exports.addTransaction = exports.listTransactions = void 0;
const LedgerService = __importStar(require("./ledger.service"));
const listTransactions = (req, res) => {
    try {
        res.json(LedgerService.listTransactions(req.query));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.listTransactions = listTransactions;
const addTransaction = (req, res) => {
    try {
        res.status(201).json(LedgerService.addTransaction(req.body));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.addTransaction = addTransaction;
const getLedgerSummary = (_req, res) => {
    try {
        res.json(LedgerService.getLedgerSummary());
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getLedgerSummary = getLedgerSummary;
const getDailyLedger = (req, res) => {
    try {
        const date = req.params.date || new Date().toISOString().split('T')[0];
        res.json(LedgerService.getDailySummary(date));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getDailyLedger = getDailyLedger;
const exportLedger = (_req, res) => {
    try {
        const csv = LedgerService.exportLedgerCSV();
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=ledger.csv');
        res.send(csv);
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.exportLedger = exportLedger;
// Dashboard
const getDashboardStats = (_req, res) => {
    try {
        res.json(LedgerService.getDashboardStats());
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getDashboardStats = getDashboardStats;
const getRevenueChart = (req, res) => {
    try {
        res.json(LedgerService.getRevenueChart(req.query.period || '30d'));
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getRevenueChart = getRevenueChart;
const getTopProducts = (_req, res) => {
    try {
        res.json(LedgerService.getTopProducts());
    }
    catch (e) {
        res.status(400).json({ message: e.message });
    }
};
exports.getTopProducts = getTopProducts;
