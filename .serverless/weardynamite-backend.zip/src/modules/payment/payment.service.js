"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processPaymentCallback = exports.initiateTransaction = exports.verifyCallbackHash = exports.generatePaymentHash = void 0;
const crypto_1 = __importDefault(require("crypto"));
const db = __importStar(require("../../utils/DynamoSim"));
const order_service_1 = require("../order/order.service");
const PAYU_MERCHANT_KEY = process.env.PAYU_MERCHANT_KEY || '';
const PAYU_SALT = process.env.PAYU_SALT || '';
/**
 * Generates the PayU hash for payment initiation.
 * Formula: sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||salt)
 */
const generatePaymentHash = (params) => {
    const { txnid, amount, productinfo, firstname, email } = params;
    const hashString = `${PAYU_MERCHANT_KEY}|${txnid}|${amount}|${productinfo}|${firstname}|${email}|||||||||||${PAYU_SALT}`;
    return crypto_1.default.createHash('sha512').update(hashString).digest('hex');
};
exports.generatePaymentHash = generatePaymentHash;
/**
 * Verifies the PayU hash received in the callback.
 * Formula: sha512(salt|status|udf10|udf9|udf8|udf7|udf6|udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key)
 */
const verifyCallbackHash = (params) => {
    const { status, txnid, amount, productinfo, firstname, email, hash, key, } = params;
    // PayU sends back udfs as well, we need to include them in the same order as in the formula if we sent them.
    // Since we sent empty udfs, we use pipes.
    const hashString = `${PAYU_SALT}|${status}|||||||||||${email}|${firstname}|${productinfo}|${amount}|${txnid}|${key}`;
    const calculatedHash = crypto_1.default.createHash('sha512').update(hashString).digest('hex');
    return calculatedHash === hash;
};
exports.verifyCallbackHash = verifyCallbackHash;
const initiateTransaction = async (data) => {
    const txnid = `TXN-${Date.now()}`;
    // 1. Create a pending order
    const orderResult = (0, order_service_1.placeOrder)(data.userId, {
        addressId: data.addressId,
        paymentMethod: 'PayU',
        items: data.items,
    });
    // 2. Save transaction mapping
    db.put({
        PK: `TXN#${txnid}`,
        SK: 'TRANSACTION',
        orderId: orderResult.orderId,
        userId: data.userId,
        status: 'Initiated',
        amount: data.amount,
    });
    // 3. Generate Hash
    const hash = (0, exports.generatePaymentHash)({
        txnid,
        amount: (data.amount || 0).toString(),
        productinfo: data.productInfo,
        firstname: data.firstname,
        email: data.email,
    });
    return {
        key: PAYU_MERCHANT_KEY,
        txnid,
        amount: data.amount,
        productinfo: data.productInfo,
        firstname: data.firstname,
        email: data.email,
        phone: data.phone,
        hash,
        surl: `${process.env.BACKEND_URL}/api/payment/payu-callback`,
        furl: `${process.env.BACKEND_URL}/api/payment/payu-callback`,
    };
};
exports.initiateTransaction = initiateTransaction;
const processPaymentCallback = async (payuResponse) => {
    const { txnid, status, mihpayid, mode } = payuResponse;
    // 1. Verify Hash
    const isValid = (0, exports.verifyCallbackHash)(payuResponse);
    if (!isValid) {
        throw new Error('Invalid payment signature');
    }
    // 2. Fetch Transaction
    const txn = db.getItem(`TXN#${txnid}`, 'TRANSACTION');
    if (!txn)
        throw new Error('Transaction not found');
    // 3. Update Transaction
    db.updateItem(`TXN#${txnid}`, 'TRANSACTION', {
        status: status === 'success' ? 'Captured' : 'Failed',
        mihpayid,
        mode,
        payuResponse,
    });
    // 4. Update Order Status
    const orderStatus = status === 'success' ? 'Confirmed' : 'Payment Failed';
    (0, order_service_1.updateOrderStatus)(txn.orderId, orderStatus);
    // 5. Clear Cart on Success
    if (status === 'success') {
        (0, order_service_1.clearCart)(txn.userId);
    }
    return {
        orderId: txn.orderId,
        status: orderStatus,
        redirectUrl: `${process.env.FRONTEND_URL}/order-status?id=${txn.orderId}`,
    };
};
exports.processPaymentCallback = processPaymentCallback;
